# Automatic build
Built website from `b3e68cd`. See https://github.com/ethereum/browser-solidity/ for details.
To use an offline copy, download `remix-b3e68cd.zip`.
